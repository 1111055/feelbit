<?php $__env->startSection('content'); ?>

	<div id="headerwrapserv" class="half">
   		<div class="container">
	    	<div class="gap"></div> 

		</div><!-- /container -->
	</div><!-- /headerwrap -->

	<div id="content-wrapper">

		<!-- BLOG POSTS -->
		<div class="container">
			<div class="row mt">
	        	<div class="centered gap fade-down section-heading">
	                <h2 class="main-title"><?php echo e($page->titulo); ?></h2>
	                <hr>
	                <p><?php echo e($page->subtitulo); ?></p>
	            </div> 
			</div><!-- row -->

					<?php $__currentLoopData = $page->desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($key % 2 == 0 || $key == 0): ?> 
						<div class="row mt gap text-center">
						 <?php endif; ?>
							<div class="col-md-6 post fade-up">
			                	
			                     <span class="<?php echo e($item->class); ?>"></span>

								<h3><?php echo e($item->titulo); ?></h3>
								<?php echo $item->descricao1; ?>

							</div>
						<?php if($key % 2 != 0): ?> 
					     </div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		

			
		</div><!-- container -->
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
     <script>
	
	$( document ).ready(function() {
	$('.backstretch').attr('style', 'height: 140px !important');
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/frontend/service.blade.php ENDPATH**/ ?>