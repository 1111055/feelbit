	<div id="preloader"></div>

    <div id="search-wrapper">
        <div class="container">
            <input id="search-box" placeholder="Search"><span class="close-trigger"><i class="fa fa-angle-up"></i></span>
        </div>
    </div>
    
        <!-- Navigation -->
        <nav  id="menu" class="nav navbar navbar-default navbar-fixed-top fadeInDown header-2" data-wow-delay="0.5s" style="max-width: 100%;margin-left: 70%;margin-top: 1%;">
			<ul>
			  <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	                  
                <li>
					<a href="<?php echo e($test['path']); ?>">
						<span class="icon">
							<i aria-hidden="true" class="<?php echo e($test['link']); ?>"></i>
						</span>
						<span><?php echo e($test['menu']); ?></span>
					</a>
				</li>
	                       
	           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	       </ul>

        </nav>
<?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/frontend/navbar.blade.php ENDPATH**/ ?>