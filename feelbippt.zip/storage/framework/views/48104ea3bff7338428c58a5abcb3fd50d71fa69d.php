	<div id="footerwrap">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
				<ul id="social-icons">
	                <li class="facebook col-lg-4"><a href="#"><i class="fa fa-facebook"></i></a></li>
	                <li class="twitter col-lg-4"><a href="#"><i class="fa fa-twitter"></i></a></li>
	                <li class="dribbble col-lg-4"><a href="#"><i class="fa fa-dribbble"></i></a></li>
	            </ul>
				</div><!--col-lg-4-->
				<div class="col-lg-4">
					<h4 class="widget-title">Sobre nós</h4>
					<p>A FeelBit é o seu parceiro no desenvolvimento de soluções inovadoras digitais. Porque o nosso principal foco é no sucesso dos nossos clientes, disponibilizamos uma equipa técnica e especializada no desenvolvimento de projetos á medida que asseguram inovação frequente, qualidade e design.</p>
				</div><!--col-lg-4-->
				<div class="col-lg-4">
					<h4 class="widget-title">Onde Estamos</h4>
					<p>Lagoa,<br/>
					Vila Nova de Famalicão.<br/>
					T: 912747706 <br/>
					E: <a href="mailto:#">geral@feelbit.com</a>
					</p>
				</div><!--col-lg-4-->
			</div><!-- row -->
		</div><!-- container -->
		<div id="footer-copyright">
			<div class="container">
				Developer by FeelBit 
			</div>
		</div>
	</div>
	
	<a id="gototop" class="gototop no-display" href="#"><i class="fa fa-angle-up"></i></a><?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/frontend/footer.blade.php ENDPATH**/ ?>