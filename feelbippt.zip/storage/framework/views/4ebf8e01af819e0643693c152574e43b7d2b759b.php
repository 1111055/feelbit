<?php $__env->startSection('content'); ?>


<style>

/* USER PROFILE PAGE */
 .card {
    margin-top: 20px;
    padding: 30px;
    background-color: rgba(214, 224, 226, 0.2);
    -webkit-border-top-left-radius:5px;
    -moz-border-top-left-radius:5px;
    border-top-left-radius:5px;
    -webkit-border-top-right-radius:5px;
    -moz-border-top-right-radius:5px;
    border-top-right-radius:5px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.card.hovercard {
    position: relative;
    padding-top: 0;
    overflow: hidden;
    text-align: center;
    background-color: #fff;
    background-color: rgba(255, 255, 255, 1);
}
.card.hovercard .card-background {
    height: 130px;
}
.card-background img {
    -webkit-filter: blur(25px);
    -moz-filter: blur(25px);
    -o-filter: blur(25px);
    -ms-filter: blur(25px);
    filter: blur(25px);
    margin-left: -100px;
    margin-top: -200px;
    min-width: 130%;
}
.card.hovercard .useravatar {
    position: absolute;
    top: 15px;
    left: 0;
    right: 0;
}
.card.hovercard .useravatar img {
    width: 100px;
    height: 100px;
    max-width: 100px;
    max-height: 100px;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    border-radius: 50%;
    border: 5px solid rgba(255, 255, 255, 0.5);
}
.card.hovercard .card-info {
    position: absolute;
    bottom: 14px;
    left: 0;
    right: 0;
}
.card.hovercard .card-info .card-title {
    padding:0 5px;
    font-size: 20px;
    line-height: 1;
    color: #262626;
    background-color: rgba(255, 255, 255, 0.1);
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
}
.card.hovercard .card-info {
    overflow: hidden;
    font-size: 12px;
    line-height: 20px;
    color: #737373;
    text-overflow: ellipsis;
}
.card.hovercard .bottom {
    padding: 0 20px;
    margin-bottom: 17px;
}
.btn-pref .btn {
    -webkit-border-radius:0 !important;
}
    
img {
    max-width: 100%;
  }

  #fileDisplayArea {
    margin-top: 2em;
    width: 100%;
    overflow-x: auto;
  }

.dot {
  height: 25px;
  width: 25px;
  border-radius: 50%;
  display: inline-block;
}

</style>
           <?php if(session('sucess')): ?>
              <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;margin-right: 32%">
                <?php echo e(session('sucess')); ?>

            </div>
            <?php endif; ?>
             <?php if($errors->any()): ?>
                  <div style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;margin-right: 32%">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
              <?php endif; ?>



              <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                   Editar Produto
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="<?php echo e(route('produto')); ?>"><i class="fa fa-product-hunt"></i> Produtos</a></li>
                    <li class="active"><a href="<?php echo e(route('produto.edit', $produto->id)); ?>"><i class="fa fa-product-hunt"></i> Editar Produto</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">             
            <!-- /.row -->
                  <div class="row">
                      <div class="col-xs-12">
                        <div class="box">
                        
                          <div class="col-lg-12 col-sm-12">
                              <div class="btn-pref btn-group btn-group-justified btn-group-lg" role="group" aria-label="...">
                                  <div class="btn-group" role="group">
                                      <button type="button" id="stars" class="btn btn-warning" href="#tab1" data-toggle="tab"><span class="fa fa-edit" aria-hidden="true"></span>
                                          <div class="hidden-xs">Produto</div>
                                      </button>
                                  </div>
                                  <div class="btn-group" role="group">
                                      <button type="button" id="following" class="btn btn-default" href="#tab3" data-toggle="tab"><span class="fa fa-image" aria-hidden="true"></span>
                                          <div class="hidden-xs">Imagens</div>
                                      </button>
                                  </div>
                              </div>

                             <div class="well">
                                <div class="tab-content">
                                  <div class="tab-pane fade in active" id="tab1">
                                      <div class="box box-info">
                                             <?php echo Form::model($produto, [
                                                  'method' => 'PUT',
                                                  'route' => ['produto.update', $produto->id],
                                                  'class' => 'form-horizontal',
                                                   'files' => true
                                             ]); ?>

                                            <div class="box-body">
                                              <div class="form-group">
                                                <?php echo Form::label('Codigo Artigo:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                <div class="col-sm-8">
                                                   <?php echo Form::text('cod_art',$produto->cod_art,['class' => 'form-control']); ?>

                                                </div>
                                              </div>
                                              <div class="form-group">
                                                <?php echo Form::label('* Titulo:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                <div class="col-sm-8">
                                                   <?php echo Form::text('titulo',$produto->titulo,['class' => 'form-control']); ?>

                                                </div>
                                              </div>
                                               <div class="form-group">
                                                  <?php echo Form::label('* Subtitulo:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::text('subtitulo',$produto->subtitulo,['class' => 'form-control']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                     <?php echo Form::label('Descricao:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::textarea('descricao',$produto->descricao,['class' => 'form-control', 'id' => 'descricao']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                    <?php echo Form::label('Lote:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::text('lote',$produto->lote,['class' => 'form-control']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                    <?php echo Form::label('Link:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::text('link',$produto->link,['class' => 'form-control']); ?>

                                                  </div>
                                                </div>
                                                 <div class="form-group">
                                                    <?php echo Form::label('Ordem:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::text('ordem',$produto->ordem,['class' => 'form-control']); ?>

                                                  </div>
                                                </div>

                                                <div class="form-group">
                                                    <?php echo Form::label('Activo:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::checkbox('activo',1,$produto->activo); ?>

                                                  </div>
                                                </div>
                                            </div>
                                             <div class="box-body">
                                                <h3>Caracteristicas</h3>
                                                <div class="form-group">
                                                    <?php echo Form::label('Categoria:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::select('categoria_id', $selcat,$produto->categoria_id,['class' => 'form-horizontal']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                    <?php echo Form::label('Sub Categoria:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::select('subcategoria_id', $selsubcat,$produto->subcategoria_id,['class' => 'form-horizontal']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                    <?php echo Form::label('Familia:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::select('familia_id', $selfam,$produto->familia_id,['class' => 'form-horizontal']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                    <?php echo Form::label('Sub Familia:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::select('subfamilia_id', $selsubcat,$produto->subfamilia_id,['class' => 'form-horizontal']); ?>

                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                       <?php echo Form::label('Prazos:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                    <div class="col-sm-8">
                                                      <?php echo Form::select('prazos_id', $selprazo,$produto->prazos_id,['class' => 'form-horizontal']); ?>

                                                    </div>
                                                  </div>
                                                  <div class="form-group">
                                                       <?php echo Form::label('Sexo:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                    <div class="col-sm-8">
                                                       <select class="form-horizontal" name="sexo" id="sexo">
                                                            <option value="0">-- Escolha uma opção --</option>
                                                            <option value="1" <?php if($produto->sexo == 1): ?>SELECTED <?php endif; ?>>Masculino</option>
                                                            <option value="2" <?php if($produto->sexo == 2): ?>SELECTED <?php endif; ?>>Feminino</option>
                                                       </select>
                                                    </div>
                                                  </div>
                                                  <div class="form-group">
                                                    <?php echo Form::label('Desconto Comercial (%):',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                      <?php echo Form::text('desconto',$produto->desconto,['class' => 'form-control']); ?>

                                                  </div>
                                                </div>
                                            </div>
                                            <div class="box-body">
                                                
                                               <div class="row">
                                                  <div class="col-md-4 offset-md-3">
                                                      <h3>Tamanhos </h3>
                                                          

                                                           <div class="col-sm-4">
                                                              <?php echo e(Form::select('sizes[]', $seltamanhos,$arrys, ['class' => 'form-control input-sm multiplePicker', 'multiple'=>'multiple'])); ?> 
                                                           </div>
                                                       
                                                   
                                                  </div>  
                                                 
                                                  <div class="col-md-6 offset-md-3">
                                                         <h3 style="margin-bottom: 3%;">Cores </h3>
                                                          <div class="col-sm-4">
                                                              <?php echo e(Form::select('cores[]', $selcores,$arry, ['class' => 'form-control input-sm multiplePicker', 'multiple'=>'multiple'])); ?> 
                                                           </div>
                                                       
                                                  </div> 
                                               </div> 
                                            </div>                                                   
                                      

                                            <div class="box-body">
                                                <h3>Outros</h3>
                                                <div class="form-group">
                                                  <?php echo Form::label('Observações Internas:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                  <div class="col-sm-8">
                                                     <?php echo Form::textarea('obs',$produto->obs,['class' => 'form-control']); ?>

                                                  </div>
                                                </div>
                                                   <div class="col-xs-2">
                                                   </div>
                                                <div class="col-xs-4">
                                                <p><div id="fileDisplayArea"></div></p>
                                                    <div class="col-xs-8">
                                                          <img src="<?php echo e($produto->path); ?>"  />
                                                    </div>
                                                </div>
                                               <div class="form-group col-sm-6">
                                                    <label>Imagem Principal (468x659)</label>
                                                     <input type="file" name="prodimg" id="exampleInputImage" class="image"> 
                                                </div>
                                            </div>
                                            <div class="box-footer">
                                                <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                            </div>
                                          <?php echo Form::close(); ?>

                                      </div>
                                  </div>
                                  <div class="tab-pane fade in" id="tab3">
                                     <div class="panel-body">
                                        <div class="box box-info">

                                             <?php echo Form::open(['url' => 'produtoimagem','class' => 'form-horizontal', 'files' => true ]); ?>


                                                 <?php echo Form::hidden('idprod',$produto->id,['class' => 'form-control']); ?>

                                                <div class="form-group">
                                                    <?php echo Form::label('Ordem:',null, ['class' => 'col-sm-1 control-label']); ?>

                                                <div class="col-sm-2">
                                                     <?php echo Form::text('ordem',null,['class' => 'form-control']); ?>

                                                </div>
                                                <div class="form-group">
                                                    <?php echo Form::label('Destacar:',null, ['class' => 'col-sm-1 control-label']); ?>

                                                  <div class="col-sm-1">
                                                     <?php echo Form::checkbox('destacar',1,true); ?>

                                                  </div>
                                                </div>
                                               <div class="form-group">
                                                    <?php echo Form::label('Activo:',null, ['class' => 'col-sm-1 control-label']); ?>

                                                  <div class="col-sm-1">
                                                     <?php echo Form::checkbox('activo',1,true); ?>

                                                  </div>
                                                </div>

                                                <div class="col-xs-2">
                                                </div>
                                                <div class="col-xs-4">
                                                <p><div id="fileDisplayArea"></div></p>
                                                    <div class="col-xs-8">
                                                          <img src="#"  />
                                                    </div>
                                                </div>
                                               <div class="form-group col-sm-6">
                                                    <label>Imagens Produto</label>
                                                    <input type="file" name="prodimg" id="exampleInputImage" class="image"> 
                                                </div>
                                                </div>
                                            <div class="box-footer">
                                                <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                            </div>
                                             <?php echo Form::close(); ?>

                                          </div>
                                        <div class="box-body table-responsive no-padding">
                                          <div class="box box-info">
                                              <table class="table table-hover">
                                                <tr>
                                                  <th class="col-xs-1">#</th>
                                                  <th>Ordem</th>
                                                  <th class="text-center">Destacar</th>
                                                  <th class="text-center">Active</th>
                                                  <th>#</th>
                                                </tr>
                                               
                                                
                                                <?php $__currentLoopData = $produto->imagensproduto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <tr>
                                                  <td class="col-xs-1"> <img src="<?php echo e($item->path); ?>"  /></td>
                                                  <td><?php echo e($item->ordem); ?></td>
                                                   <?php if($item->destacar === 1): ?>
                                                    <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                                  <?php else: ?>                       
                                                     <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                                  <?php endif; ?>  
                                                  <?php if($item->activo === 1): ?>
                                                     <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                                  <?php else: ?>                       
                                                    <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                                  <?php endif; ?>   
                                                  <td><a href="<?php echo e(route('banner.edit',$item->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a> 

                                                  <?php echo e(Form::open(['route' => ['banner.destroy', $item->id], 'method' => 'delete'])); ?>

                                                  <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                                  <?php echo e(Form::close()); ?>


                                                  </td>
                                                   </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                              </table>
                                           </div>
                                        </div>
                                      </div>
                                 </div>
                                </div>
                              </div>
                         </div>
                        </div>
                        <!-- /.box -->
                      </div>
                     </div>
                  </div>

                </section>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/backend/Produto/edit.blade.php ENDPATH**/ ?>