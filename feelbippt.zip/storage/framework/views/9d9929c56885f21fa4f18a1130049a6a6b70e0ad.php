<?php $__env->startSection('content'); ?>


         <?php if(session('sucess')): ?>
         <!--Alerta de sucess-->
            <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
              <?php echo e(session('sucess')); ?>

          </div>
          <?php endif; ?>
           <?php if($errors->any()): ?>
                <div style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

              <div class="content-wrapper">
                <section class="content-header">
                  <h1>
                    Banners
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="<?php echo e(route('banner')); ?>"><i class="fa fa-sliders"></i> Banners</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">             
            <!-- /.row -->
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="box">
                        <div class="box-header">
                           <?php if(Auth::user()->isinrule(['supermaster'])): ?>
                             <div class="panel panel-default">
                                <div class="panel-body">
                                <!-- Horizontal Form -->
                                  <div class="col-xs-12">
                                    <div class="box box-info">
                                         <?php echo Form::open(['url' => 'banner','class' => 'form-horizontal']); ?>

                                            <div class="box-body">
                                                  <div class="col-xs-8">
                                                     <div class="form-group col-xs-10">
                                                       <?php echo Form::label('* Titulo '); ?>

                                                       <?php echo Form::hidden('produto',1,['class' => 'form-control']); ?>

                                                       <?php echo Form::text('titulo',null,['class' => 'form-control']); ?>

                                                     </div>
                                                  </div>
                                                 <div class="col-xs-4">
                                                    <div class="form-group col-xs-6">
                                                      <?php echo Form::label('Ordem:'); ?>

                                                      <?php echo Form::text('ordem',null,['class' => 'form-control']); ?>

                                                    </div>
                                                 </div>

                                            </div>
                                            <div class="box-footer">
                                                <?php echo Form::submit('Novo',['class' => 'btn btn-info pull-right']); ?>

                                            </div>
                                          <?php echo Form::close(); ?>

                                      </div>
                                    </div>
                                  </div>
                              </div>
                          <?php endif; ?>
                                                         </div>
                                    </div>
                                  </div>
                              </div>
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="box">
                        <div class="box-body table-responsive no-padding">
                          <table class="table table-hover">
                            <tr>
                              <th>#</th>
                              <th>Titulo</th>
                              <th>Descrição</th>
                              <th>Width</th>
                              <th>Height</th>
                              <th>Ordem</th>
                              <th class="text-center">Active</th>
                            </tr>
                             <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td>#</td>
                                <td><?php echo e($item->titulo); ?></td>
                                <td><?php echo e($item->descricao); ?></td>
                                <td><?php echo e($item->width); ?></td>
                                <td><?php echo e($item->height); ?></td>
                                <td><?php echo e($item->ordem); ?></td>
                                <?php if($item->activo === 1): ?>
                                    <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                <?php else: ?>                       
                                <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                <?php endif; ?>   
                                <td><div class="col-xs-1"><a href="<?php echo e(route('banner.edit',$item->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a></div>
                                  <div class="col-xs-1"> 

                                      <?php echo e(Form::open(['route' => ['banner.destroy', $item->id], 'method' => 'delete'])); ?>

                                      <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                      <?php echo e(Form::close()); ?>


                                  </div>
                                </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                        </div>
                        <!-- /.box-body -->
                      </div>
                      <!-- /.box -->
                    </div>
                  </div>

                </section>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Produto/banner.blade.php ENDPATH**/ ?>