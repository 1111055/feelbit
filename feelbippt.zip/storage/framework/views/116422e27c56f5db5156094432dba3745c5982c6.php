<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($data->subject); ?>


Exº <?php echo e($data->nome); ?>


<center>
Acusa-mos a recepção do seu pedido de contacto. <br><br>
</center>

<center>
A equipa Feel Bit agradeçe o seu interesse, brevemente receberá noticias nossas. <br><br>
</center>

Os seus dados:

Nome: <?php echo e($data->nome); ?>

<hr>
Email: <?php echo e($data->email); ?>

<hr>
Assunto: <?php echo e($data->subject); ?>

<hr>
Descrição: <?php echo e($data->desc); ?>

<hr>

<br><br>


<center>
<strong>Até já.</strong> 
</center>

<br><br>


www.feelbit.pt<br>
Feel Bit
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Emails/thanks.blade.php ENDPATH**/ ?>