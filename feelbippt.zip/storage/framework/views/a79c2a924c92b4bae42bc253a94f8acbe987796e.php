<?php $__env->startSection('content'); ?>


 <?php echo $__env->make('backend.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


              <div class="content-wrapper">
                <section class="content-header">
                  <h1>
                   Menus
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active"><a href="<?php echo e(route('menu')); ?>"><i class="fa fa-align-justify"></i> Menus</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid" >             
            <!-- /.row -->
                      <div class="row">
                        <div class="col-xs-12">
                          <div class="box">
                             <?php if(Auth::user()->isinrule(['supermaster'])): ?>
                                <div class="box-header">
                                
                                     <div class="panel panel-default">
                                        <div class="panel-body">
                                        <!-- Horizontal Form -->
                                          <div class="col-xs-12">
                                            <div class="box box-info">
                                              <?php echo Form::open(['url' => 'menu','class' => 'form-horizontal']); ?>

                                                    <div class="box-body">
                                                      <div class="form-group">
                                                        <?php echo Form::label('* Menu:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                        <div class="col-sm-4">
                                                           <?php echo Form::text('menu',null,['class' => 'form-control']); ?>

                                                        </div>
                                                           <?php echo Form::label('* Ordem:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                        <div class="col-sm-4">
                                                           <?php echo Form::text('ordem',null,['class' => 'form-control']); ?>

                                                        </div>
                                                          
                                                      </div>

                                                    </div>
                                                    <div class="box-footer">
                                                        <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                                    </div>
                                                  <?php echo Form::close(); ?>

                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                   
                                  </div>
                              <?php endif; ?> 
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-xs-12">
                            <div class="box">
                              <div class="box-body table-responsive no-padding">
                                <table class="table table-hover">
                                  <tr>
                                    <th>Ordem</th>
                                    <th>Menu</th>
                                    <th>Pagina</th>
                                    <th>Descrição</th>
                                    <th class="text-center">Active</th>
                                    <th>#</th>
                                  </tr>
                                   <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e($item->ordem); ?></td>
                                      <td><?php echo e($item->menu); ?></td>
                                      <td><?php echo e($item->link); ?></td>
                                      <td><?php echo e($item->descricao); ?></td>
                                      <?php if($item->activo === 1): ?>
                                          <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                      <?php else: ?>                       
                                      <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                      <?php endif; ?>   
                                      <td><div class="col-xs-1"><a href="<?php echo e(route('menu.edit',$item->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a> </div>
                                          <div class="col-xs-1">
                                             <?php if(Auth::user()->isinrule(['supermaster'])): ?>
                                                <?php echo e(Form::open(['route' => ['menu.destroy', $item->id], 'method' => 'delete'])); ?>

                                                   <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                                <?php echo e(Form::close()); ?>

                                             <?php endif; ?>   
                                          </div>
                                      </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                              </div>
                            </div>
                         </div>
                       </div>
                </section>
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Menu/index.blade.php ENDPATH**/ ?>