         <?php if(session('sucess')): ?>
         <!--Alerta de sucess-->
            <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;margin-right: 30%;">
              <?php echo e(session('sucess')); ?>

          </div>
          <?php endif; ?>
           <?php if($errors->any()): ?>
                <div class="alert alert-danger" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;margin-right: 30%;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


<?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/alert.blade.php ENDPATH**/ ?>