
<?php echo $__env->make('frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">


                <?php echo $__env->make('frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    			 <?php echo $__env->yieldContent('content'); ?>

    	
    		  	<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


           <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>  
            <script src="<?php echo e(asset('js/modernizr.custom.js')); ?>"></script>   
                <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-154453478-1"></script>

            <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
            <!-- Plugin JavaScript -->
            <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
            <!-- Custom Theme JavaScript -->
            <script src="<?php echo e(asset('js/theme.js')); ?>"></script>

            <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

             <script src="<?php echo e(asset('js/pluginstwo.js')); ?>"></script>

            <script src="<?php echo e(asset('js/imagesloaded.js')); ?>"></script>

            <script src="<?php echo e(asset('js/prettyPhoto.js')); ?>"></script>

            <script src="<?php echo e(asset('js/init.js')); ?>"></script>



            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());

              gtag('config', 'UA-154453478-1');


                $(document).ready(function(){
                    jQuery('#headerwrap').backstretch([
                      "image/bg/bg6.jpg"
                    ], {duration: 4000, fade: 500});

                    jQuery('#headerwraplap').backstretch([
                      "../image/bg/lap.jpg"
                    ], {duration: 4000, fade: 500});
                    jQuery('#headerwrapserv').backstretch([
                      "../image/bg/serv.jpg"
                    ], {duration: 4000, fade: 500});
                    jQuery('#headerwrlok').backstretch([
                      "image/bg/looked.jpg"
                    ], {duration: 4000, fade: 500});


                    
                });
            </script>
            <?php echo $__env->yieldContent('scripts'); ?>


     </body>
 </html>
<?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/frontend/app.blade.php ENDPATH**/ ?>