<?php $__env->startSection('content'); ?>


         <?php if(session('sucess')): ?>
         <!--Alerta de sucess-->
            <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
              <?php echo e(session('sucess')); ?>

          </div>
          <?php endif; ?>
           <?php if($errors->any()): ?>
                <div style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

              <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                    Pedidos Orçamentos
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active"><a href="<?php echo e(route('orcamento')); ?>"><i class="fa fa-newspaper-o"></i> Pedidos Orçamentos</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">     

                   <div class="container">
                       <div class="panel panel-default">
                          <div class="panel-heading">Filtros</div>
                           <div class="panel-body">
                            <div class="box-header">

                              <div class="box-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                                  <div class="input-group-btn">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                  </div>        
            <!-- /.row -->
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="box">
                        <div class="box-body table-responsive no-padding">
                          <table class="table table-hover">
                            <tr>
                              <th>Numero Orçamento</th>
                              <th>Nome</th>
                              <th>Email</th>
                              <th>Telefone</th>
                              <th>Empresa</th>
                              <th>Data</th>
                              <th>Ficheiro</th>
                              <th>Obs</th>
                            </tr>
                            <?php $__currentLoopData = $orcamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td> <a href="<?php echo e(route('orcamento.show', $item->id)); ?>"><?php echo e($item->id); ?></a></td>
                                <td><?php echo e($item->nome); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->telemovel); ?></td>
                                <td><?php echo e($item->empresa); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td> 
                                    
                                    <?php if(file_exists(public_path().'/logotipo/orcamento/'.$item->pathfile) &&  !empty($item->pathfile)): ?>

                                      <a href="<?php echo e((route('orcamento.download',[$item->pathfile,$item->id]))); ?>" target="_blank"> Link </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->obs); ?></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>

                </section>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/backend/Orcamento/index.blade.php ENDPATH**/ ?>