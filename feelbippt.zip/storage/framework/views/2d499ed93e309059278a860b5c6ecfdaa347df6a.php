<?php $__env->startSection('content'); ?>



    <style type="text/css">
      
      img {
          max-width: 100%;
        }

        #fileDisplayArea {
          margin-top: 2em;
          width: 100%;
          overflow-x: auto;
        }

    </style>

               <?php echo $__env->make('backend.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    


              <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                   Settings
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active"><a href="<?php echo e(route('setting')); ?>"><i class="fa fa-wrench"></i> Settings</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">             
            <!-- /.row -->
                 <div class="row justify-content-md-center">
                    <div class="col-xs-12">
                      <div class="box">
                        <div class="box-header">
                          <h3 class="box-title">Settings</h3>

                         <div class="panel panel-default">
                            <div class="panel-body">
                            <?php echo Form::model($setting, [
                                  'method' => 'PUT',
                                  'route' => ['setting.update', $setting->id],
                                  'class' => 'form-horizontal',
                                  'files' => true
                             ]); ?>

                              <div class="col-xs-4">
                                <div class="box box-info">
                                        <div class="box-body">

                                              <div class="form-group">
                                                 <?php echo Form::label('Nome '); ?>

                                                 <?php echo Form::text('nome',$setting->nome,['class' => 'form-control']); ?>

                                              </div>
                                              <div class="form-group">
                                                <?php echo Form::label('Contacto:'); ?>

                                                <?php echo Form::text('contacto1',$setting->contacto1,['class' => 'form-control']); ?>

                                              </div>
                                              <div class="form-group">
                                                <?php echo Form::label('Contacto:'); ?>

                                                <?php echo Form::text('contacto2',$setting->contacto2,['class' => 'form-control']); ?>

                                              </div>
                                            
                                              <div class="form-group">
                                                <?php echo Form::label('Email:'); ?>

                                                <?php echo Form::text('email1',$setting->email1,['class' => 'form-control']); ?>

                                              </div>
                                              <div class="form-group">
                                                <?php echo Form::label('Email:'); ?>

                                                <?php echo Form::text('email2',$setting->email2,['class' => 'form-control']); ?>

                                              </div>
                                              <div class="form-group">
                                                <?php echo Form::label('Website:'); ?>

                                                <?php echo Form::text('website',$setting->website,['class' => 'form-control']); ?>

                                              </div>
                                              <div class="form-group">

                                                 <input type="file" name="profile_image" id="exampleInputImage" class="image">
                                              

                                                 <div class="col-xs-12">
                                                    <p><div id="fileDisplayArea"></div></p>
                                                    <?php if(session('path')): ?>
                                                        <img src="<?php echo e(session('path')); ?>" />
                                                    <?php endif; ?>
                          													<?php if(file_exists('logotipo/CROP/logotipo.png')): ?>
                          														<img src="logotipo/CROP/logotipo.png" />
                          													<?php endif; ?>
                                               </div> 
                                              </div>
                                               
                                                                     
                                       </div>

                                  </div>
                                </div>
                                 <div class="col-xs-4">
                                      <div class="box box-info">
                                              <div class="box-body">
                                                   <div class="form-group">
                                                      <?php echo Form::label('Rua:'); ?>

                                                      <?php echo Form::text('rua',$setting->rua,['class' => 'form-control']); ?>

                                                    </div>
                                                   <div class="form-group">
                                                      <?php echo Form::label('Localidade:'); ?>

                                                      <?php echo Form::text('localidade',$setting->localidade,['class' => 'form-control']); ?>

                                                    </div>
                                                   <div class="form-group">
                                                      <?php echo Form::label('Cidade:'); ?>

                                                      <?php echo Form::text('cidade',$setting->cidade,['class' => 'form-control']); ?>

                                                    </div>
                                                    <div class="form-group">
                                                      <?php echo Form::label('Codigo Postal:'); ?>

                                                      <?php echo Form::text('codigopostal',$setting->codigopostal,['class' => 'form-control']); ?>

                                                    </div>
                                                    <div class="form-group">
                                                      <?php echo Form::label('Latitude:'); ?>

                                                      <?php echo Form::text('latitude',$setting->latitude,['class' => 'form-control']); ?>

                                                    </div>
                                                    <div class="form-group">
                                                      <?php echo Form::label('Longitude:'); ?>

                                                      <?php echo Form::text('longitude',$setting->longitude,['class' => 'form-control']); ?>

                                                    </div>
                                                     
                                                   <div class="box-footer">
                                                      <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                                  </div>
                                                                  
                                             </div>

                                        </div>
                                    </div>
                                 <?php echo Form::close(); ?>     

                              </div>
                            </div>
                        </div>
                      </div>
                      <!-- /.box -->
                    </div>
                  </div>

                </section>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Setting/index.blade.php ENDPATH**/ ?>