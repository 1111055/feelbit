<?php $__env->startSection('content'); ?>


         <?php if(session('sucess')): ?>
         <!--Alerta de sucess-->
            <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
              <?php echo e(session('sucess')); ?>

          </div>
          <?php endif; ?>
           <?php if($errors->any()): ?>
                <div style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

              <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                  Tamanhos
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active"><a href="<?php echo e(route('size')); ?>"><i class="fa fa-paint-brush"></i> Tamanhos</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">             
            <!-- /.row -->
                                  <div class="row">
                                    <div class="col-xs-12">
                                      <div class="box">
                                        <div class="box-header">

                                          <!-- /.adicionar um novo -->
                                         <div class="panel panel-default">
                                            <div class="panel-body">
                                            <!-- Horizontal Form -->
                                              <div class="col-xs-12">
                                                <div class="box box-info">
                                                  <?php echo Form::open(['url' => 'size','class' => 'form-horizontal']); ?>

                                                        <div class="box-body">
                                                          <div class="form-group">
                                                            <?php echo Form::label('* Titulo:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                            <div class="col-sm-4">
                                                               <?php echo Form::text('titulo',null,['class' => 'form-control']); ?>

                                                            </div>
                                                              <?php echo Form::label('Ordem:',null, ['class' => 'col-sm-2 control-label']); ?>

                                                            <div class="col-sm-4">
                                                               <?php echo Form::text('ordem',null,['class' => 'form-control']); ?>

                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="box-footer">
                                                            <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                                        </div>
                                                <?php echo Form::close(); ?>

                                                  </div>
                                                </div>
                                             </div>
                                         </div>
                                        </div>
                                       </div>
                                     </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-xs-12">
                                      <div class="box">
                                        <div class="box-body table-responsive no-padding">
                                          <table class="table table-hover">
                                            <tr>
                                              <th>#</th>
                                              <th>Titulo</th>
                                              <th>Subtitulo</th>
                                              <th>Tamanhos</th>
                                              <th>Ordem</th>
                                              <th class="text-center">Active</th>
                                              <th>#</th>
                                            </tr>
                                            <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                <td>#</td>
                                                <td><?php echo e($item->titulo); ?></td>
                                                <td><?php echo e($item->subtitulo); ?></td>
                                                <td><?php echo e($item->tamanho); ?></td>
                                                <td><?php echo e($item->ordem); ?></td>
                                                <?php if($item->activo === 1): ?>
                                                    <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                                <?php else: ?>                       
                                                <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                                <?php endif; ?>   
                                                <td> <div class="col-xs-1"><a href="<?php echo e(route('size.edit',$item->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a> </div>
                                                  <div class="col-xs-1">
                                                    <?php echo e(Form::open(['route' => ['size.destroy', $item->id], 'method' => 'delete'])); ?>

                                                    <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                                    <?php echo e(Form::close()); ?>

                                                  </div>
                                                </td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </table>
                                       </div>
                                      </div>
                                    </div>
                                 </div>

                 </section>
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Size/index.blade.php ENDPATH**/ ?>