<?php $__env->startSection('content'); ?>


           <?php if(session('sucess')): ?>
            <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
              <?php echo e(session('sucess')); ?>

           </div>
           <?php endif; ?>
           <?php if($errors->any()): ?>
                <div style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

              <div class="content-wrapper">
                <section class="content-header">
                  <h1>
                  Newsletter
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active"><a href="<?php echo e(route('newsletter')); ?>"><i class="fa fa-newspaper-o"></i> Newsletter</a></li>
                  </ol>
                </section>

                <section class="content container-fluid">             
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="box">
                        <div class="box-body table-responsive no-padding">
                          <table class="table table-hover">
                            <tr>
                              <th>#</th>
                              <th>Email</th>
                              <th>Data</th>
                              <th class="text-center">Active</th>
                            </tr>
                            <?php $__currentLoopData = $newsletter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td>#</td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <?php if($item->activo === 1): ?>
                                    <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                <?php else: ?>                       
                                    <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                <?php endif; ?>   
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>

                </section>
              </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Newsletter/index.blade.php ENDPATH**/ ?>