<?php $__env->startSection('content'); ?>

<!-- MAIN IMAGE SECTION -->
	<div id="headerwraplap" class="half">
   		<div class="container">
	    	<div class="gap"></div> 

		</div><!-- /container -->
	</div><!-- /headerwrap -->

	<div id="content-wrapper">
	    <section id="about">
	   		<div class="container">
		    	<div class="gap"></div>
				<div class="row gap">
					        	<div id="bannertext" class="centered fade-down section-heading">
					                <h2 class="main-title"><?php echo e($pageabout->titulo); ?></h2>
					                <hr>
					                <p><?php echo e($pageabout->subtitulo); ?></p>
					            </div>

					<div class="col-md-12 text-justify">
						<?php echo $pageabout->descricao1; ?>

						 <a href="<?php echo e(route('contactos')); ?>"  class="btn btn-outlined btn-primary btn-lg bounce-in" type="submit" name="submit" /><?php echo e($exp[2]['expression']); ?></a>
				    </div>

			</div>	
	    </section>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/frontend/about.blade.php ENDPATH**/ ?>