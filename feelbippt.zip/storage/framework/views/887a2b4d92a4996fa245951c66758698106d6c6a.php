<?php $__env->startSection('content'); ?>


 <?php echo $__env->make('backend.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
              <div class="content-wrapper">
                <section class="content-header">
                  <h1>
                    Pedidos Contactos
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="<?php echo e(route('contactos')); ?>"><i class="fa fa-phone"></i> Contactos</a></li>
                    <li class="active"><a href="<?php echo e(route('contactos.show',$contactos->id)); ?>"><i class="fa fa-phone"></i> Detalhe Contacto</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid">             
                  <div class="row">
                    <div class="col-xs-12">
                      <div class="box">

                       <div class="col-xs-12">
                          <div class="panel panel-default">
                            <div class="panel-body">
                             <div class="col-xs-6">
                              <ul class="list-group">
                                <li class="list-group-item">Nome: <?php echo e($contactos->nome); ?></li>
                                <li class="list-group-item">Email: <?php echo e($contactos->email); ?></li>
                                <li class="list-group-item">Assunto: <?php echo e($contactos->assunto); ?></li>
                                <li class="list-group-item">Descricao: <?php echo e($contactos->message); ?></li>
                                <li class="list-group-item">Data: <?php echo e($contactos->created_at); ?></li>
                              </ul>
                             <div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </section>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/Contactos/show.blade.php ENDPATH**/ ?>