<?php $__env->startSection('content'); ?>


	<!-- MAIN IMAGE SECTION -->
	<div id="headerwrap">
		<span class="headerwrap-btn-wrap">
			<a href="#content-wrapper" class="headerwrap-btn"><i class="fade-up fa fa-angle-down"></i></a>
		</span>	
	</div><!-- /headerwrap -->

	<div id="content-wrapper">
	    <section id="about" class="section-wrapper">
	   		<div class="container">
	        	<div class="centered gap fade-down section-heading">
	                <h2 class="main-title"><?php echo e($paginas[1]['titulo']); ?></h2>
	                <hr>
	              			  <?php echo $paginas[1]['descricao']; ?>

	            </div>

	            <div class="row gap">
		            <div class="col-md-8 col-md-offset-2">
		            	<img src="<?php echo e(asset('/image/pub.jpg')); ?>" class="fade-up img-responsive" alt="Alt" />
		            </div>
	            </div>

			</div>	
	    </section>

		<section id="services" class="divider-wrapper">
			<div class="container">
	        	<div class="centered gap fade-down section-heading">
	                <h2 class="main-title"><?php echo e($paginas[3]['titulo']); ?></h2>
	                <hr>
	              			<?php echo $paginas[3]['descricao']; ?>

	            </div>
				<div class="row">

					 <?php $__currentLoopData = $paginas[3]->desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-1 col-md-1 col-sm-1 centered bounce-in">
							<span class="<?php echo e($item->class); ?>"></span>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-2 fade-up">
							<h3><?php echo e($item->titulo); ?></h3>
							<p><?php echo e($item->descricao); ?></p>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
				</div>
			</div><!-- container -->
	    </section>

	    		<!-- CLIENTS LOGOS -->
		<div class="grey">
			<div class="container">

				<div class="row">
		        	<div class="centered gap fade-down section-heading">
		                <h2 class="main-title"><?php echo e($paginas[5]['titulo']); ?></h2>
		                <hr>
		              <?php echo $paginas[5]['descricao']; ?>

		            </div> 
				</div><!-- row -->

				<div class="row centered">
					<div id="logo-carousel" class="fade-up">
						<div class="item">
							<img src="<?php echo e(asset('image/logo/1.png')); ?>" alt="">
						</div>
						<div class="item">
							<img src="<?php echo e(asset('image/logo/2.png')); ?>" alt="">
						</div>
						<div class="item">
							<img src="<?php echo e(asset('image/logo/3.png')); ?>" alt="">
						</div>
						<div class="item">
							<img src="<?php echo e(asset('image/logo/4.png')); ?>" alt="">
						</div>
					</div>
				</div><!-- row -->
			</div><!-- container -->
		</div><!-- dg -->
		

		<section id="testimonials" class="divider-wrapper">
			<div class="container">
				<div class="centered gap fade-down section-heading">
	                <h2 class="main-title"><?php echo e($paginas[2]['titulo']); ?></h2>
	                <hr>
	                 <?php echo $paginas[2]['descricao']; ?>

	            </div> 
			    <div class="row mt">
			        <?php $__currentLoopData = $paginas[2]->desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			              <?php if($k % 2 == 0): ?>
					        <div class="col-md-6">
					      <?php endif; ?>  	
					            <div class="blockquote-box fade-up clearfix">
					                <div class="square pull-left">
					                   <i class="<?php echo e($item->class); ?>" aria-hidden="true"></i>
					                </div>
					                <h4><?php echo e($item->titulo); ?></h4>
					                <p><?php echo e($item->descricao); ?></p>
					            </div>
					      <?php if($k % 2 == 0): ?>
					        </div>  
					      <?php endif; ?>  	
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			    </div>
			</div>
	    </section>

		<div id="call">
			<div class="container">
				<div class="row fade-up">
					<h3>Newsletter</h3>
					<div class="col-lg-8 col-lg-offset-2">
						<p>Subscreva a nossa newsletter e mantenha-se sempre atualizado.</p>
						<form method="post"  action="newsletter/teste" id="searchForm">
							 <input name="crf" id="crf" type="hidden" value="<?php echo e(csrf_token()); ?>">
					      	<p><input type="text" class="form-control" name="email" id="email" placeholder="Email" /></p>

							<div class="alert alert-danger" role="alert" id="alerterro" style="display: none;"></div>

							<input class="btn btn-outlined btn-primary btn-lg bounce-in" type="submit" name="submit" value="Enviar" />
					    </form>
					</div>
				</div><!-- row --> 
			</div><!-- container -->
		</div><!-- Call to action -->
		
		<div class="container">
			<div class="row mt">
	        	<div class="centered gap fade-down section-heading">
	                <h2 class="main-title">Contacte-nos</h2>
	                <hr>
	                <p>Para mais informações sobre os nossos serviços contacte-nos. Teremos ao seu dispor uma equipa dedicada para o ajudar.</p>
	            </div>
			</div><!-- row -->
		</div><!-- container -->
		<div class="container" id="contact-us">
			<div class="row gap">
				<div class="fade-up col-md-6 fade-up">
					<p>"Eu tentei 99 vezes e falhei, mas na centésima vez eu consegui. Nunca desista de seus objetivos, mesmo que eles pareçam impossíveis, a próxima tentativa pode ser a vitoriosa."</p>
					<p>Albert Einstein</p>
				</div>
				<div class="fade-up col-md-6 fade-up">
					<div id="message"></div>
					<form method="post" id="contact-form" class="contact-form">
						<input name="_token" id="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
						<p><input type="text" class="form-control" name="nome" id="nome" placeholder="Nome" /></p>
						<div class="col-md-12">
                    
                             <div class="alert alert-danger" role="alert" id="erronome" style="display: none;"></div>
                 
                        </div>
						<p><input type="text" class="form-control" name="email" id="email" placeholder="Email" /></p>
						<div class="col-md-12">

                             <div class="alert alert-danger" role="alert" id="erroemail" style="display: none;"></div>

                        </div>
						<p><input type="text" class="form-control" name="website" id="website" placeholder="Website" /></p>
						<p><textarea name="subject" class="form-control" id="subject" placeholder="Discrição"></textarea></p>
				    	<div class="col-md-12">
                        
                             <div class="alert alert-danger" role="alert" id="erroemail" style="display: none;"></div>
                         
                        </div>
						<input class="btn btn-outlined btn-primary" type="submit" name="submit" id="sendcontact" value="Enviar" />
					     <div class="fa-3x" style="display: none;" id="loaderorca">
                            <i class="fa fa-spinner fa-pulse" style="margin-left: 50%;"></i>
                        </div>
                        <div class="alert alert-success" role="alert" id="enviosucesso" style="display: none;"></div>
					</form>
				</div>
			</div><!-- row -->
		</div>

	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/frontend/index.blade.php ENDPATH**/ ?>