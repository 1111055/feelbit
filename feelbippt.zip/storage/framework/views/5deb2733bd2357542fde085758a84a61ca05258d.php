	<div id="footerwrap">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
				<ul id="social-icons">
				
				  <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	               <a href="<?php echo e($item->link); ?>" target="_blank"> <li class="<?php echo e(strtolower($item->nome)); ?> col-lg-4"><i class="<?php echo e($item->class); ?>"></i></li></a>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
	            </ul>
				</div><!--col-lg-4-->
				<div class="col-lg-4">
					<h4 class="widget-title"><?php echo e($exp[6]['expression']); ?></h4>
					<p><?php echo e($exp[6]['descricao']); ?></p>
				</div><!--col-lg-4-->
				<div class="col-lg-4">
					<h4 class="widget-title">Onde Estamos</h4>
					<p><?php echo e($setting->rua); ?>, <?php echo e($setting->localidade); ?>  <br/>
					<?php echo e($setting->cidade); ?>.<br/>
					T: <?php echo e($setting->contacto1); ?> <br/>
					E: <?php echo e($setting->email1); ?>

					</p>
				</div><!--col-lg-4-->
			</div><!-- row -->
		</div><!-- container -->
		<div id="footer-copyright">
			<div class="container">
				<?php echo e($exp[7]['expression']); ?>

			</div>
		</div>
	</div>
	
	<a id="gototop" class="gototop no-display" href="#"><i class="fa fa-angle-up"></i></a><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/frontend/footer.blade.php ENDPATH**/ ?>