<!doctype html>
<html class="no-js" lang="en-US">
<?php echo $__env->make('backend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
            <?php echo $__env->make('backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			      <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <?php echo $__env->yieldContent('content'); ?>

	
		       	<?php echo $__env->make('backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.rightsite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 3 -->
    <script src="<?php echo e(asset('backend/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('backend/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('backend/dist/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
     <script src="<?php echo e(asset('backend/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>


    <script src="<?php echo e(asset('backend/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/multiselect2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/bower_components/chart.js/Chart.js')); ?>"></script>

    <script>
      $(function () {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
         CKEDITOR.replace('descricao')
         CKEDITOR.replace('descricao1')
         CKEDITOR.replace('descricao2')
  
        //bootstrap WYSIHTML5 - text editor
        $('.textarea').wysihtml5()
      })

        $(document).ready(function() {
            $(".btn-pref .btn").click(function () {
                $(".btn-pref .btn").removeClass("btn-warning").addClass("btn-default");
                // $(".tab").addClass("active"); // instead of this do the below 
                $(this).removeClass("btn-default").addClass("btn-warning");   
            });
        });

       $("#add").on('click', function () {
             
               var html = '<input type="text" name="titulo[]" id="titulo" class="form-control" /> <input type="text" name="titulo[]" id="titulo" class="form-control" /> </br>';
         

                $(".addlines").append(html);


        });


    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

function validateform(este)
{    

     
    var erro = false;
      
    jQuery("input[type='text']",este).each(function()
    { 
              
        if(erro==false && jQuery(this).attr("require") == 1 && jQuery.trim(jQuery(this).val()) == "" )
        {   
                          
            erro = true;
            $(this).focus();
            $(this).next("span").text("Erro - Campo Obrigatório");
            $(this).next("span").css("display", "block").delay( 2000 ).fadeOut(); 
                       
        }


        
        
        if(erro==false && jQuery(this).attr("minl")>0 && jQuery.trim(jQuery(this).val()).length < jQuery(this).attr("minl"))
        {
        
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("maxl")>0 && jQuery.trim(jQuery(this).val()).length < jQuery(this).attr("maxl"))
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if( erro==false && jQuery(this).attr("email") == 1 && jQuery.trim(jQuery(this).val()) == "")
        {
             
            erro = true;
            $(this).focus();
            $(this).next("span").text("Erro - Campo Obrigatório");
            $(this).next("span").css("display", "block").delay( 2000 ).fadeOut(); 
       
        }



        if( erro==false && jQuery(this).attr("email") == 1 && isEmail(jQuery.trim(jQuery(this).val())) == false)
        {
             
            erro = true;
            $(this).focus();
            $(this).next("span").text("Erro - Formato do Email");
            $(this).next("span").css("display", "block").delay( 2000 ).fadeOut(); 
       
        }



        if(erro==false && jQuery(this).attr("numerico") == 1 && isNaN(jQuery(this).val())==true)
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("email") == 1 && jQuery("input[name='new_email']",este).attr('name') == 'new_email' && validate_email(jQuery(this)) == false)
        {   
            
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("email") == 1 && jQuery("input[name='email_newsletter']",este).attr('name') == 'email_newsletter' && validate_email_newsletter(jQuery(this)) == false)
        {
       
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery("input[name='userlogin']",este).attr('name') == 'userlogin' && validate_email_login(jQuery(this)) == false)
        {      
                                      
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
    })
    
    jQuery("select",este).each(function()
    {
        if(erro==false && jQuery(this).attr("require") == 1 && ( jQuery.trim(jQuery(this).val()) == "" || ( jQuery.trim(jQuery(this).val()) == 0 && jQuery(this).attr("withzero") != 1 )))
        {
            erro = true;
            jQuery(this).addClass('form error'); 
            $(this).focus();
        }
    })


    jQuery("input[type='password']",este).each(function()
    {

      
       if(erro==false && jQuery(this).attr("require") == 1 && ($("input[name=password]").val() == ""  || $("input[name=passwordconfirme]").val() == ""))
        {    
        
            erro = true;
            $(this).focus();
            $(this).next("span").text("Erro - Campo Obrigatório");
            $(this).next("span").css("display", "block").delay( 2000 ).fadeOut(); 
            
        }
         
        if (erro==false && ($("input[name=password]").val() != $("input[name=passwordconfirme]").val())) {
        
            erro = true;
            $(this).focus();
            $(this).next("span").text("Erro - Não Correspondem.");
            $(this).next("span").css("display", "block").delay( 2000 ).fadeOut(); 

        }
        
        if(erro==false && jQuery(this).attr("require") == 1 && jQuery.trim(jQuery(this).val()) == "")
        {    
        
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
            
        }
        if(erro==false && jQuery(this).attr("minl")>0 && jQuery.trim(jQuery(this).val()).length < jQuery(this).attr("minl") && jQuery.trim(jQuery(this).val()) != "")
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("maxl")>0 && jQuery.trim(jQuery(this).val()).length >= jQuery(this).attr("maxl"))
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("equalTo") != '' && jQuery("input[id='"+jQuery(this).attr("equalTo")+"']",este).val()==jQuery(this).val())
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("match") == 1 && jQuery("input[wrefo='"+jQuery(this).attr("wref")+"']",este).val()!=jQuery(this).val())
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        if(erro==false && jQuery(this).attr("user_password") == 1 && !validate_password(jQuery(this)))
        {
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
        
       
        if(erro==false && jQuery("input[name='password_login']",este).attr('name') == 'password_login' && validate_login(jQuery(this)) == false)
        {
        
            var msgerro2 = document.getElementById("msgerro2").value;
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
          

        }
   
   

     })
    
        
    jQuery("textarea",este).each(function()
    {
    
     
        if(erro==false && jQuery(this).attr("require") == 1 && jQuery.trim(jQuery(this).val()) == "")
        {
          
            erro = true;
            jQuery(this).addClass('form error');
            $(this).focus();
        }
    })


    jQuery("input[type='checkbox']",este).each(function()
    {
        if(erro==false && jQuery(this).attr("require") == 1 && !jQuery(this).is(':checked'))
        {
        
           //var hv = $('#msgterms').val(); 
            erro = true;
            $('.errorToolTip').show();
         
           
        }
    })
    
    
     jQuery("input[type='file']",este).each(function()
    {
   
        if(erro==false && jQuery(this).attr("require") == 1 && jQuery.trim(jQuery(this).val()) == "")
        {
          
            erro = true;
            jQuery(this).parents('.inputError').addClass('displayError');
            $(this).focus();
            $('.form-message .error', este).fadeIn();    
            return false;
      
        }
        
        
    }) 

    

    if(erro == false){
  
     //$('.form-message .success').show();
     return true;
    } 
    else { 
    
      
        return false;
    }
}

function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}


    $(document).ready(function () {
        $('.multiplePicker').multiselect();
    });

    </script>

    </body>
</html><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/backend/app.blade.php ENDPATH**/ ?>