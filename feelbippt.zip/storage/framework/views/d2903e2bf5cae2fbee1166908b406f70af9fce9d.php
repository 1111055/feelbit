
<?php echo $__env->make('frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">


                <?php echo $__env->make('frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    			 <?php echo $__env->yieldContent('content'); ?>

    	
    		  	<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
            <!-- Plugin JavaScript -->
            <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
            <!-- Custom Theme JavaScript -->
            <script src="<?php echo e(asset('js/theme.js')); ?>"></script>

            <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

             <script src="<?php echo e(asset('js/pluginstwo.js')); ?>"></script>

            <script src="<?php echo e(asset('js/imagesloaded.js')); ?>"></script>

            <script src="<?php echo e(asset('js/prettyPhoto.js')); ?>"></script>

            <script src="<?php echo e(asset('js/init.js')); ?>"></script>


     </body>
 </html>
<?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/frontend/app.blade.php ENDPATH**/ ?>