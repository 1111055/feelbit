<?php $__env->startSection('content'); ?>


              <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                   Dashboard
                  </h1>
                  <ol class="breadcrumb">
                    <li class="active"><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Dashcoard</a></li>
                  </ol>
                </section>

                <!-- Main content -->
                <section class="content container-fluid" style="background-image: url('backend/dist/img/logo.png') ;  background-repeat: no-repeat;
              background-position: 50% 50%;  opacity: 0.3;">


                     


                </section>
                <!-- /.content -->
              </div>
              <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/backend/index.blade.php ENDPATH**/ ?>