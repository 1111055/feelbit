<?php $__env->startSection('content'); ?>

<!-- MAIN IMAGE SECTION -->
	<div id="headerwrlok" class="half">
   		<div class="container">
	    	<div class="gap"></div> 

		</div><!-- /container -->
	</div><!-- /headerwrap -->

	<div id="content-wrapper">
	    <section id="about">
	   		<div class="container">
				<div class="row gap">
					        	<div id="bannertext" class="centered fade-down section-heading">
					                <h2 class="main-title"><?php echo e($pagepolicy->nome); ?></h2>
					            </div>

					<div class="col-md-12 text-justify">
						<?php echo $pagepolicy->descricao; ?>

						
				    </div>

			</div>	
	    </section>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
     <script>
	
	$( document ).ready(function() {
	$('.backstretch').attr('style', 'height: 140px !important');
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feelbippt\resources\views/frontend/policy.blade.php ENDPATH**/ ?>