<?php $__env->startSection('content'); ?>

         <?php if(session('sucess')): ?>
         <!--Alerta de sucess-->
            <div class="alert alert-success" id="showsucess" style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
              <?php echo e(session('sucess')); ?>

          </div>
          <?php endif; ?>
           <?php if($errors->any()): ?>
                <div style="border-radius: 0; float: right; margin-top: 2%; position: fixed; right: 0; top: 0; width: 600px; z-index: 9999;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

              <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                    Editar Menu
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('dash')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="<?php echo e(route('menu')); ?>"><i class="fa fa-align-justify"></i> Menus</a></li>
                    <li class="active"><a href="<?php echo e(route('menu.edit', $menu->id)); ?>"><i class="fa fa-align-justify"></i>Editar Menu</a></li>
                  </ol>
                </section>

                <section class="content container-fluid">             
            <!-- /.row -->
                  <div class="row">
                      <div class="col-xs-12">
                        <div class="box">
                        
                         <div class="panel panel-default">
                            <div class="panel-body">
                            <div class="box box-info">
                                     <?php echo Form::model($menu, [
                                          'method' => 'PUT',
                                          'route' => ['menu.update', $menu->id],
                                          'class' => 'form-horizontal'
                                     ]); ?>

                                    <div class="box-body">
                                      <div class="form-group">
                                        <?php echo Form::label('* Menu:',null, ['class' => 'col-sm-2 control-label']); ?>

                                        <div class="col-sm-8">
                                           <?php echo Form::text('menu',$menu->menu,['class' => 'form-control']); ?>

                                        </div>
                                        
                                      </div>
                                      <div class="form-group">
                                           <?php echo Form::label('* Descricao:',null, ['class' => 'col-sm-2 control-label']); ?>

                                        <div class="col-sm-8">
                                           <?php echo Form::textarea('descricao',$menu->descricao,['class' => 'form-control']); ?>

                                        </div>
                                      </div>
                                       <div class="form-group">
                                          <?php echo Form::label('* Submenu:',null, ['class' => 'col-sm-2 control-label']); ?>

                                        <div class="col-sm-8">
                                           <?php echo Form::select('submenu', $selmenu,$menu->submenu,['class' => 'form-horizontal']); ?>

                                        </div>
                                      </div>
                                      <div class="form-group">
                                          <?php echo Form::label('* Link:',null, ['class' => 'col-sm-2 control-label']); ?>

                                        <div class="col-sm-8">
                                           <?php echo Form::text('link',$menu->link,['class' => 'form-control']); ?>

                                        </div>
                                       </div>
                                       <div class="form-group">
                                           <?php echo Form::label('* Ordem:',null, ['class' => 'col-sm-2 control-label']); ?>

                                         <div class="col-sm-8">
                                           <?php echo Form::text('ordem',$menu->ordem,['class' => 'form-control']); ?>

                                         </div>
                                      </div>
                                      <?php if(Auth::user()->isinrule(['supermaster'])): ?>
                                      <div class="form-group">
                                           <?php echo Form::label('Path:',null, ['class' => 'col-sm-2 control-label']); ?>

                                         <div class="col-sm-8">
                                           <?php echo Form::text('path',$menu->path,['class' => 'form-control']); ?>

                                         </div>
                                      </div>
                                      <?php endif; ?>

                                    </div>
                                    <div class="box-footer">
                                        <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                    </div>
                                  <?php echo Form::close(); ?>

                              </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-header">
                              <label>Submenu</label>
                            </div>
                            <div class="panel-body">
                              <?php if(Auth::user()->isinrule(['supermaster'])): ?>
                                <div class="col-xs-12">
                                  <div class="box box-info">
                                    <?php echo Form::open(['url' => 'menu','class' => 'form-horizontal']); ?>

                                          <div class="box-body">
                                            <div class="form-group">
                                             <?php echo Form::hidden('submenu',$menu->id,['class' => 'form-control']); ?>

                                              <?php echo Form::label('* Menu:',null, ['class' => 'col-sm-2 control-label']); ?>

                                              <div class="col-sm-4">
                                                 <?php echo Form::text('menu',null,['class' => 'form-control']); ?>

                                              </div>
                                                 <?php echo Form::label('* Ordem:',null, ['class' => 'col-sm-2 control-label']); ?>

                                              <div class="col-sm-4">
                                                 <?php echo Form::text('ordem',null,['class' => 'form-control']); ?>

                                              </div>
                                                
                                            </div>

                                          </div>
                                          <div class="box-footer">
                                              <?php echo Form::submit('Guardar',['class' => 'btn btn-info pull-right']); ?>

                                          </div>
                                        <?php echo Form::close(); ?>

                                    </div>
                                  </div>
                                <?php endif; ?>
                                 <div class=" row col-xs-12 box-body table-responsive no-padding">
                                    <table class="table table-hover">
                                      <tr>
                                        <th>Ordem</th>
                                        <th>Menu</th>
                                        <th>Pagina</th>
                                        <th>Descrição</th>
                                        <th class="text-center">Active</th>
                                        <th>#</th>
                                      </tr>
                                       <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <td><?php echo e($item->ordem); ?></td>
                                          <td><?php echo e($item->menu); ?></td>
                                          <td><?php echo e($item->link); ?></td>
                                          <td><?php echo e($item->descricao); ?></td>
                                          <?php if($item->activo === 1): ?>
                                              <td class="text-center"><i class="fa fa-check-circle"></i></td>
                                          <?php else: ?>                       
                                          <td class="text-center"><i class="fa fa-times-circle"></i></td>
                                          <?php endif; ?>   
                                          <td><a href="<?php echo e(route('menu.edit',$item->id)); ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a> 
                                            <?php if(Auth::user()->isinrule(['supermaster'])): ?>
                                              <?php echo e(Form::open(['route' => ['menu.destroy', $item->id], 'method' => 'delete'])); ?>

                                              <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                              <?php echo e(Form::close()); ?>

                                            <?php endif; ?>  

                                          </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                  </div>
                              </div>
                        </div>

                      </div>
                     </div>
                  </div>

                </section>
              </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MM\feelbit\resources\views/backend/Menu/edit.blade.php ENDPATH**/ ?>