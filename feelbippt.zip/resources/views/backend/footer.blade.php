
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      www.feelbit.pt
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2019<a href="#"></a>  Feel Bit.</strong> All rights reserved.
  </footer>