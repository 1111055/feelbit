@component('mail::message')


<center>
O seu email foi registado com sucesso. <br><br>
</center>

<center>
A partir de agora recebe as nossas novidades. <br><br>
</center>

<center>
Fique atento ao seu email. <br><br>
</center>

<br><br>

<center>
<strong>Até já.</strong> 
</center>

<br><br>


www.feelbit.pt<br>
Feel Bit
@endcomponent
